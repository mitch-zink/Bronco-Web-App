<!--
  Takes you to homepage.php
-->
<?php
  header('Location: ../start/login.php');
?>