First page of the site is home/home.php

User:admin
Password:admin