<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="../css.css">
</head>
<body>


<?php
include("../navbar.php")
?>
<?php 
echo "<h1>Home</h1>";
echo "<hr>";
echo "<h3><pre>1966 – 1977 Early Ford Bronco Expense & Project Tracker for DIY Vehicle Restoration</pre></h3>";
?>
</body>

</html>