<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="../css.css">
</head>
<body>
<?php
include("../navbar.php")
?>
<?php //print to screen FAQ
echo "<h1>FAQ</h1>";
echo "<hr>";
echo "<h3><pre>1) Can I create more than one project?
Answer: Yes, you can create as many projects as you can manage.
2) Can I delete a project after I‘ve sold it?
Answer: No, this data is historical and should be preserved.
3) Can I use this tool to track other makes, models and years of project cars?
Answer: Yes, other data is populated in the tables for this purpose.
</h3></pre>";
?>

