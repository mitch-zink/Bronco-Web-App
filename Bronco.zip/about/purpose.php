<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="../css.css">
</head>
<body>

<?php
include("../navbar.php")
?>
<?php 
echo "<h1>Purpose</h1>";
echo "<hr>";
echo "<h3><pre>This website is designed for the 1966 – 1977 Early Ford Bronco enthusiast to track vehicle 
expenses & maintenance from the initial purchase to the bittersweet day when ownership changes hands. 
It also provides a convenient location to store files, such as user manuals, warranties, receipts, invoices, 
pictures & videos. Hover over “Start Here” and click on “Create User Account” to begin.
</h3></pre>";
?>
</body>
</html>
